Prince of Persia The Two Thrones: The Unofficial Patch.


 This patch will fix most of the problems left for 18 years by UBISOFT.

Mouse input is improved dramatically, but it is still not perfect (The only problem left is decreased camera speed when you run and look UP and DOWN)
The reason why ? Folks from Ubisoft decided to hard code that part of the camera in a very weird way, which is very hard to fix without source code.
In the Vanilla version you can only move the camera in x or y-axis (THERE WAS NO DIAGONAL SUPPORT) which made playing this game on a mouse almost impossible. Thankfully, I manage to fix that problem. 

Ubisoft made this game so bad that almost every function including mouse and camera speed is frame rate based and tied to 100 other functions, so in order to fix that i had to lock the game to 60fps and untied camera functions.
Now you have to find good mouse setting in game in order to make it good. On my mouse with, 16000 Dpi the perfect setting is on 40%.
If you have 800dpi mouse, you need to set game mouse sens on 100% or increase it in windows for more speed.

I also complacently rework how this camera behaves, which means now you can control this camera without any blockers.
Ubisoft made deadzones for mouse input for some stupid reasons, but I have managed to remove it for the most part (I can't completely disable it because of the way they codded that thing)

To make this the definitive version of the game, I also included fixes from other Mod makers to make the process of fixing this game as much simple as possible for you all.
Now you don't have to change any .ini files for proper widescreen or 4K. 
I made it so it all "Just Works" out of the box without any pain.

I can't fix every broken part without source code, but i will try when i have the time and energy for this mess.
It took me a full month to fix this game on my free time, so if you like this project and want more content like this in the future, please consider supporting me to ease some pain from this mess.  

https://www.paypal.com/donate/?hosted_button_id=62DCK8LJ8B8CN

Fixes made by me:

- FOV increase to be more like Xbox Version
- Diagonal support for Camera and Mouse.
- Removed Camera Auto Center when you run.
- Removed Camera Auto Center in static cameras.
- Increased Camera speed.
- Tweaked Dead Zones to be 99% gone(I can't remove it completely because of the way Ubisoft coded that think)
- Tweaked Mouse movement and speed. (Not perfect but it is playable now)
- Fixed Contrast and gamma settings.
- 60 fps lock (The game is broken when you play in more than 60fps)
- Removed Broken MSAA option from the game.

Fixed made by other mod makers:

- DX11 conversion using DgVoodoo. (You can use Reshade now if you want and other tools like that)
- Proper 4xMSAA by default.
- Restored Gore Effects.
- Proper 16:9 support without any .ini tweaks.
- Fog and glow fix
- Fixed UI.

Fixes that are possible but not currently in this patch.

- Restored some better textures from the PS2 version
- Major Texture update using AI ESRGAN.

If you know how to repack .bin files from THE JADE GAME ENGINE please let me know !!!!
I want to remaster all the textures to make this game at least on par with other games in the trilogy.

To install, just copy all files to Prince of Persia Tho Thrones main folder where the .exe is.

